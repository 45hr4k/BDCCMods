extends Module

# Species spawn rates, configured before the game starts via FoxLib "Mod Options".
# Each species gets a slider (relative weight, 100% = vanilla default) and a preview button.
# The weights are written into the save's EncounterSettings (same values as the in-game Encounters menu).

const PreviewWindow = preload("res://Modules/SpeciesSpawnRates/PreviewWindow.tscn")

const CATEGORY = "Species spawn rates"

var applyMode = "always"
var weights = {} # speciesID -> slider value (0..100), kept in sync by FoxLib
var speciesOrder = []

func _init():
	id = "SpeciesSpawnRates"
	author = "45hr4k"

func onFoxLibModInit(foxModuleAPI):
	# Called after all mods are loaded, so modded species are included here
	foxModuleAPI.addListOptionInCategory(CATEGORY, "applyMode", "Apply to", [
		["always", "New games and every loaded save"],
		["newgame", "New games only"],
		["off", "Off (use in-game Encounters menu)"],
	], "When the slider values are written into the game's species weights.\n'Every loaded save' overwrites changes made in the in-game Encounters menu each time a save is loaded.", "always")

	var allSpecies = GlobalRegistry.getAllSpecies()
	speciesOrder = []
	for speciesID in allSpecies:
		var species = allSpecies[speciesID]
		if(species == null || speciesID == "error" || !species.isPlayable()):
			continue
		speciesOrder.append(speciesID)
	speciesOrder.sort_custom(self, "sortByName")

	for speciesID in speciesOrder:
		var species = allSpecies[speciesID]
		var defaultValue = int(round(clamp(species.npcGenerationWeight(), 0.0, 1.0) * 100.0))
		foxModuleAPI.addSliderOptionInCategory(CATEGORY, "weight_"+speciesID, species.getVisibleName(),
			"Relative chance for "+species.getVisibleName()+" ("+speciesID+").\n100% = vanilla default, 0% = never.\nThe actual share is this value divided by the sum of all sliders.", defaultValue).bindToField(weights, speciesID)
		var button = foxModuleAPI.addButtonOptionInCategory(CATEGORY, "preview_"+speciesID, "Preview: "+species.getVisibleName(),
			"Generates a random "+species.getVisibleName()+" character to look at.")
		var _ok = button.connect("option_changed", self, "onPreviewPressed", [speciesID])

func sortByName(a, b):
	return GlobalRegistry.getSpecies(a).getVisibleName() < GlobalRegistry.getSpecies(b).getVisibleName()

func getWeight(speciesID) -> float:
	if(!weights.has(speciesID) || weights[speciesID] == null):
		return 0.0
	return max(0.0, float(weights[speciesID]) / 100.0)

func getChances() -> Dictionary:
	var total = 0.0
	for speciesID in speciesOrder:
		total += getWeight(speciesID)
	var result = {}
	for speciesID in speciesOrder:
		result[speciesID] = (getWeight(speciesID) / total * 100.0) if total > 0.0 else 0.0
	return result

func onPreviewPressed(_value, speciesID):
	var tree = Engine.get_main_loop()
	if(!(tree is SceneTree)):
		return
	var window = PreviewWindow.instance()
	window.module = self
	window.speciesID = speciesID
	tree.root.add_child(window)

# FoxLib event: Godot scene changed
func onSceneChanged(newScene):
	if(!str(newScene).begins_with("MainScene:[")):
		return
	if(applyMode == "off" || !is_instance_valid(GM.main)):
		return
	# Fresh MainScene = new game (a loaded save replaces these values afterwards)
	applyWeights()
	if(applyMode == "always" && !GM.main.is_connected("saveLoadingFinished", self, "onSaveLoaded")):
		var _ok = GM.main.connect("saveLoadingFinished", self, "onSaveLoaded")

func onSaveLoaded():
	if(applyMode == "always"):
		applyWeights()

func applyWeights():
	if(!is_instance_valid(GM.main)):
		return
	var encounterSettings = GM.main.getEncounterSettings()
	for speciesID in speciesOrder:
		encounterSettings.setSpeciesWeight(speciesID, getWeight(speciesID))
	Log.print("[SpeciesSpawnRates] Applied species weights: "+str(encounterSettings.speciesWeights))
