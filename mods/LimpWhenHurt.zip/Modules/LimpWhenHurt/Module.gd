extends Module

# Characters limp while walking when their health (pain left until defeat) is low.
# Every Doll3D that enters the scene tree gets a LimpWatcher child.

const LimpWatcher := preload("res://Modules/LimpWhenHurt/limp_watcher.gd")
const WATCHER_NAME := "LimpWatcher"

var limp_below_health_percent := 70


func _init() -> void:
	id = "LimpWhenHurt"
	author = "45hr4k"
	var tree := Engine.get_main_loop()
	if tree is SceneTree and not tree.is_connected("node_added", self, "_on_node_added"):
		var _err := tree.connect("node_added", self, "_on_node_added")


# Called by FoxLib (if installed); without FoxLib the value stays at 70.
func onFoxLibModInit(fox_module_api) -> void:
	fox_module_api.addNumberOptionInCategory(
		"Limp when hurt",
		"limp_below_health",
		"Limp below health (%)",
		"Characters limp while walking when their health is below this percentage. "
		+ "Health is the pain they can still take before they are defeated (100% = no pain).",
		70).bindToField(self, "limp_below_health_percent")


func _on_node_added(node: Node) -> void:
	if node is Doll3D:
		# Deferred: the doll is still being added to the tree right now.
		call_deferred("_add_watcher", weakref(node))


# A doll can enter the tree more than once (reparented), it keeps its first watcher
func _add_watcher(doll_ref: WeakRef) -> void:
	var doll = doll_ref.get_ref()
	if doll == null or not is_instance_valid(doll) or doll.has_node(WATCHER_NAME):
		return
	var watcher := LimpWatcher.new()
	watcher.name = WATCHER_NAME
	watcher.settings = self
	doll.add_child(watcher)
