extends Node

# Added to every Doll3D by Module.gd. Swaps the doll's walk and stand animations
# for the limp versions while its character's health is low.

const LIMP_ANIMATIONS := {
	"Walk-loop": preload("res://Modules/LimpWhenHurt/limp_walk.tres"),
	"Standing-loop": preload("res://Modules/LimpWhenHurt/limp_stand.tres"),
	"StandingToWalking": preload("res://Modules/LimpWhenHurt/limp_stand_to_walk.tres"),
	"WalkingToStanding": preload("res://Modules/LimpWhenHurt/limp_walk_to_stand.tres"),
}
# Swapping one of these while it plays makes the posture jump
const WALKING_ANIMATIONS := ["Walk-loop", "StandingToWalking", "WalkingToStanding"]
const CHECK_INTERVAL := 0.5 # seconds
# Where the stage scenes keep their state machine playback.
const PLAYBACK_PARAMETERS := [
	"parameters/AnimationNodeStateMachine/playback",
	"parameters/playback",
]

var settings = null
var doll = null
var player: AnimationPlayer = null
var playback: AnimationNodeStateMachinePlayback = null
var original_animations := {}
var is_limping := false
var time_since_check := 0.0


func _ready() -> void:
	doll = get_parent()
	player = doll.getAnimPlayer()
	for animation_name in LIMP_ANIMATIONS:
		var original := player.get_animation(animation_name)
		if original == null:
			set_process(false)
			return
		original_animations[animation_name] = original
	# A doll that is already hurt starts limping right away.
	_set_limping(_should_limp())


func _process(delta: float) -> void:
	time_since_check += delta
	if time_since_check < CHECK_INTERVAL:
		return
	time_since_check = 0.0
	var limping := _should_limp()
	# Switch only when the doll is not walking, so the posture doesn't change mid-step.
	if limping != is_limping and _is_walking():
		return
	_set_limping(limping)


func _should_limp() -> bool:
	var character_id = doll.getCharacterID()
	if character_id == null or (character_id is String and character_id == ""):
		return false
	# Preview dolls hold the character object itself instead of an ID.
	var character = doll.getCharFromID(character_id)
	if (character == null or not is_instance_valid(character)
			or not character.has_method("getPainLevel")):
		return false
	var health: float = 1.0 - character.getPainLevel()
	return health < settings.limp_below_health_percent / 100.0


func _set_limping(limping: bool) -> void:
	if limping == is_limping:
		return
	is_limping = limping
	for animation_name in LIMP_ANIMATIONS:
		var animation: Animation = (LIMP_ANIMATIONS[animation_name] if limping
				else original_animations[animation_name])
		var _err := player.add_animation(animation_name, animation)


# Stage scenes drive the doll with an AnimationTree state machine, other dolls play directly.
func _is_walking() -> bool:
	if playback == null:
		playback = _find_playback()
	if playback != null:
		return playback.get_current_node() in WALKING_ANIMATIONS
	return player.is_playing() and player.current_animation in WALKING_ANIMATIONS


# The stage scene's AnimationTree that drives this doll is a sibling of the doll.
func _find_playback() -> AnimationNodeStateMachinePlayback:
	var stage = doll.get_parent()
	if stage == null:
		return null
	for child in stage.get_children():
		if not child is AnimationTree or child.get_node_or_null(child.anim_player) != player:
			continue
		for parameter in PLAYBACK_PARAMETERS:
			var found = child.get(parameter)
			if found is AnimationNodeStateMachinePlayback:
				return found
	return null
