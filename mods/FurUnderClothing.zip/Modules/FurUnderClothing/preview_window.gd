extends CanvasLayer

# The same character twice, left without and right with the clipping. A real generated character
# with real items, so breast size and the parts that clothes hide (Item.getHidesParts) match the
# game.
# Built in code, opened from the FoxLib options (works in the main menu, no running game needed).

const DOLL_SCENE = "res://Player/Player3D/Doll3D.tscn"
const VIEWPORT_CONTROL_SCENE = "res://UI/CustomViewportControl.tscn"
const SPECIES = "canine"
const PREVIEW_SLOTS = ["body", "arms", "breasts", "legs"]
const GENDERS = [["Female", "female"], ["Male", "male"]]
const CLOTHING = [
	["Naked", ""],
	["Undershirt", "plainUndershirt"],
	["Inmate uniform", "inmateuniformSexDeviant"],
	["Casual clothes", "CasualClothes"],
	["Leather jacket", "LeatherJacket"],
	["Bra", "plainBra"],
	["Briefs", "plainBriefs"],
]
const PREFERRED_NAME_START = "Fluffy" # picked first, if installed
const FEMALE_BREASTS = 3 # BreastsSize.C

var module = null

var _dolls := []
var _character = null
var _character_gender := ""
var _species_parts := {} # slot -> id of the generated character's own bodypart
var _species_breasts_size := 0
var _part_choices := {} # slot -> [[name, bodypart id or "" for the species' own part]]
var _selectors := {} # slot -> OptionButton
var _gender_selector: OptionButton
var _clothing_choices := []
var _clothing_selector: OptionButton
var _options: GridContainer
var _hint: Label


func _ready() -> void:
	layer = 100
	var dim = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	dim.anchor_right = 1.0
	dim.anchor_bottom = 1.0
	add_child(dim)

	var panel = PanelContainer.new()
	panel.anchor_left = 0.5
	panel.anchor_top = 0.5
	panel.anchor_right = 0.5
	panel.anchor_bottom = 0.5
	panel.margin_left = -400
	panel.margin_top = -330
	panel.margin_right = 400
	panel.margin_bottom = 330
	dim.add_child(panel)

	var box = VBoxContainer.new()
	panel.add_child(box)
	var title = Label.new()
	title.text = "Fur under clothing: preview"
	title.align = Label.ALIGN_CENTER
	box.add_child(title)

	var views = HBoxContainer.new()
	views.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_child(views)
	for doll_mode in [module.MODE_OFF, module.MODE_CLOTHED]:
		var column = VBoxContainer.new()
		column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		views.add_child(column)
		var label = Label.new()
		label.align = Label.ALIGN_CENTER
		if doll_mode == module.MODE_OFF:
			label.text = "Without the mod"
		else:
			label.text = "With the mod (Under clothing)"
		column.add_child(label)
		_dolls.append(_create_doll_view(column, doll_mode))

	var options = GridContainer.new()
	options.columns = 4
	box.add_child(options)
	var hint = Label.new()
	hint.autowrap = true
	box.add_child(hint)
	var close_button = Button.new()
	close_button.text = "Close"
	var _err = close_button.connect("pressed", self, "queue_free")
	box.add_child(close_button)

	_options = options
	_hint = hint
	if module.preview_parts.empty():
		# Loading every bodypart scene takes a few seconds, show the window first. A timer
		# connection (unlike a yield) is dropped when the window is closed in the meantime.
		hint.text = "Searching installed fur bodyparts..."
		_err = get_tree().create_timer(0.1).connect("timeout", self, "_search_fur_parts")
	else:
		_fill_options()


func _search_fur_parts() -> void:
	for slot in PREVIEW_SLOTS:
		module.preview_parts[slot] = _find_fur_parts(slot)
	_fill_options()


func _fill_options() -> void:
	_hint.text = ("Lists all installed fur bodyparts. Fur is only cut where clothing covers it, "
			+ "uncovered fur keeps its tufts.")
	var options = _options
	for slot in PREVIEW_SLOTS:
		_part_choices[slot] = [["Vanilla", ""]] + module.preview_parts[slot]
		_selectors[slot] = _add_selector(options, slot.capitalize(), _part_choices[slot],
				_preferred_index(_part_choices[slot]))
	for entry in CLOTHING:
		if entry[1] == "" or GlobalRegistry.get("items").has(entry[1]):
			_clothing_choices.append(entry)
	_clothing_selector = _add_selector(options, "Clothing", _clothing_choices,
			int(min(1, _clothing_choices.size() - 1)))
	_gender_selector = _add_selector(options, "Gender", GENDERS, 0)
	_update_dolls()


func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		get_tree().set_input_as_handled()
		queue_free()


func _create_doll_view(parent: Control, doll_mode: int) -> Node:
	var wrapper = Control.new()
	wrapper.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	wrapper.size_flags_vertical = Control.SIZE_EXPAND_FILL
	wrapper.rect_min_size = Vector2(300, 440)
	parent.add_child(wrapper)

	var viewport = Viewport.new()
	viewport.name = "Viewport"
	viewport.size = Vector2(32, 32)
	viewport.own_world = true
	viewport.transparent_bg = true
	viewport.render_target_v_flip = true
	viewport.render_target_update_mode = Viewport.UPDATE_ALWAYS
	wrapper.add_child(viewport)
	var camera = Camera.new()
	camera.projection = Camera.PROJECTION_ORTHOGONAL
	camera.size = 6.0
	camera.translation = Vector3(0.2, 5.0, 50.0)
	camera.environment = Environment.new()
	viewport.add_child(camera)
	camera.make_current()

	# Doll3D.checkDirection() calls get_scale() on its parent, which a Viewport doesn't have
	var holder = Spatial.new()
	viewport.add_child(holder)
	var doll = load(DOLL_SCENE).instance()
	doll.set_meta(module.META_MODE, doll_mode)
	holder.add_child(doll)

	var view = load(VIEWPORT_CONTROL_SCENE).instance()
	view.viewportPath = NodePath("../Viewport")
	view.anchor_right = 1.0
	view.anchor_bottom = 1.0
	view.texture = viewport.get_texture()
	wrapper.add_child(view)
	return doll


func _add_selector(grid: GridContainer, text: String, choices: Array,
		selected: int) -> OptionButton:
	var label = Label.new()
	label.text = text
	grid.add_child(label)
	var selector = OptionButton.new()
	selector.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for choice in choices:
		selector.add_item(choice[0])
	selector.select(selected)
	var _err = selector.connect("item_selected", self, "_on_selection_changed")
	grid.add_child(selector)
	return selector


func _on_selection_changed(_index: int) -> void:
	_update_dolls()


# A gender change generates a new character, the generator sets up bodyparts, breast size and skin
# the way the game does. Other changes swap parts and items on it, so its look stays the same.
func _update_dolls() -> void:
	var gender = GENDERS[_gender_selector.selected][1]
	if _character == null or _character_gender != gender:
		if _character != null and is_instance_valid(_character):
			_character.queue_free()
		var generator = CharacterGeneratorBase.new()
		_character = generator.generate({"editor_noequip": true, "addtonode": self,
				NpcGen.Gender: gender, NpcGen.Species: SPECIES})
		_character_gender = gender
		_species_parts = {}
		for slot in PREVIEW_SLOTS:
			if _character.hasBodypart(slot):
				_species_parts[slot] = _character.getBodypart(slot).id
		if _character.hasBodypart(BodypartSlot.Breasts):
			_species_breasts_size = int(_character.getBodypart(BodypartSlot.Breasts).size)

	for slot in PREVIEW_SLOTS:
		var bodypart_id = _part_choices[slot][_selectors[slot].selected][1]
		if bodypart_id == "":
			bodypart_id = _species_parts.get(slot, "")
		if bodypart_id == "":
			continue
		var bodypart = GlobalRegistry.createBodypart(bodypart_id)
		if bodypart == null:
			continue
		if slot == BodypartSlot.Breasts and "size" in bodypart:
			bodypart.size = _species_breasts_size
			if gender == NpcGender.Female:
				bodypart.size = int(max(bodypart.size, FEMALE_BREASTS))
		_character.giveBodypart(bodypart, false)

	var inventory = _character.getInventory()
	for item in inventory.getAllEquippedItems().values():
		var _removed = inventory.removeEquippedItem(item)
	var item_id = _clothing_choices[_clothing_selector.selected][1]
	if item_id != "":
		var item = GlobalRegistry.createItem(item_id)
		if item != null:
			var _ok = inventory.equipItem(item)

	for doll in _dolls:
		doll.prepareCharacter(_character)
		_character.updateDoll(doll)


static func _preferred_index(choices: Array) -> int:
	for i in range(choices.size()):
		if choices[i][0].begins_with(PREFERRED_NAME_START):
			return i
	return 1 if choices.size() > 1 else 0


# Bodyparts of the slot whose doll scene has at least one mesh with its own fur texture,
# as [name, id]
func _find_fur_parts(slot: String) -> Array:
	var result = []
	var seen_scenes = {}
	for bodypart_id in GlobalRegistry.getBodypartsIdsBySlot(slot):
		var bodypart = GlobalRegistry.getBodypartRef(bodypart_id)
		var path = bodypart.getDoll3DScene() if bodypart != null else null
		if not path is String or path == "" or seen_scenes.has(path) or not _can_load(path):
			continue
		seen_scenes[path] = true
		var scene = load(path)
		if not scene is PackedScene:
			continue
		var instance = scene.instance()
		if _has_fur(instance):
			result.append([bodypart.getName(), bodypart_id])
		instance.free()
	result.sort_custom(self, "_sort_by_name")
	return result


# Scenes of other mods can point to files that are gone, load() would fill the log with errors
static func _can_load(path: String) -> bool:
	if not ResourceLoader.exists(path):
		return false
	for dependency in ResourceLoader.get_dependencies(path):
		if not ResourceLoader.exists(dependency.split("::")[0]):
			return false
	return true


func _has_fur(root: Node) -> bool:
	var stack = [root]
	while not stack.empty():
		var node = stack.pop_back()
		if node is MeshInstanceWithPattern and module.find_mask(node) != null:
			return true
		for child in node.get_children():
			stack.append(child)
	return false


static func _sort_by_name(a: Array, b: Array) -> bool:
	return a[0] < b[0]
