extends Module

# Keeps fur from poking out through clothing, configured via FoxLib "Mod Options".
# No game files are replaced.
#
# Fur bodyparts of mods (e.g. WintersFluffyBodyparts) reuse the vanilla meshes and only set
# MeshInstanceWithPattern.customAlbedo to a texture with tufts drawn outside the vanilla outline.
# Clothing is made for the vanilla outline, so the tufts stick out. The vanilla texture is still in
# the mesh's own material and serves as the mask: covered fur meshes show a copy of their texture
# cut to the vanilla shape, with the vanilla outline along the cut. Clothing made from a copy of the
# bodypart's mesh covers exactly where its texture is opaque (plus a margin for the tufts), other
# clothing skinned to the same bones covers the whole fur mesh.
# Works for every mod that uses customAlbedo, without data per mod.
# Only the texture_albedo parameter is swapped, so shader patches of other mods are not affected.

const CATEGORY = "Fur under clothing"
const MESH_GROUP = "FurUnderClothingMesh"
const META_MASK = "fuc_mask_texture"
const META_FUR = "fuc_fur_texture"
const META_MODE = "fuc_mode" # on a Doll3D: overrides the option for that doll (preview window)
const PREVIEW_WINDOW = preload("res://Modules/FurUnderClothing/preview_window.gd")

const MODE_OFF = 0
const MODE_CLOTHED = 1
const MODE_ALWAYS = 2

const FUR_BONE_SHARE = 0.2 # bones that carry at least this share of a fur mesh's skin weights
const CLOTHING_BONE_SHARE = 0.05 # same for clothing, lower because clothes span many bones
const EDGE_WIDTH = 4.0 # width of the vanilla outline kept along the cut, in vanilla texture pixels
# The mask must keep at least this share of the fur's pixels, otherwise it isn't the same shape
# (unrelated texture in the template material, or a vanilla texture with a hollow interior)
const MIN_KEPT_SHARE = 0.7
const MAX_ASPECT_DIFFERENCE = 0.02
const GEOMETRY_TOLERANCE = 0.01 # doll units, for telling whether clothing uses the bodypart's mesh
# How far around the clothing fur gets cut, in vanilla texture pixels (the tufts are up to ~15 px)
const COVER_GROW = 20.0
const REGION_SCALE = 4
# Fur that is drawn to lie on top of clothing and is never cut: per texture file, the fur that the
# same mod's variant without it doesn't have. Neck ruff of WintersFluffyBodyparts' "Scruffy body
# with neck fluff": cutting it at the collar leaves a torn piece in front of the neck.
const KEEP_EXTRA_FUR = {
	"ScruffyBodyNeckFluff.png":
			"res://Modules/WintersFluffyBodyparts/Bodyparts/Scruffy/ScruffyBody/ScruffyBody.png",
}
const KEEP_GROW = 6 # pixels around the kept fur: its outline and the vanilla line under its base
const CACHE_DIR = "user://fur_under_clothing_cache/"
const CACHE_VERSION = 5 # raise when the clipping algorithm changes, the cache is then cleared
const CACHE_MAX_FILES = 400

var mode = MODE_CLOTHED

var _pending_dolls := {} # Doll3D instance id -> weakref
var _clipped_cache := {} # "fur|mask[|covers]" hashes -> ImageTexture, null if it can't be clipped
var _clipped_textures := {} # ImageTexture -> true, to tell our textures from other mods' ones
var _texture_hashes := {} # resource path -> md5 of the pixels
var _cache_dir_checked := false
var preview_parts := {} # slot -> [[name, doll scene]] of fur bodyparts, for the preview window
var _bone_cache := {} # "mesh|skin" -> {bone name: share of the skin weights}


func _init():
	id = "FurUnderClothing"
	author = "45hr4k"

	var tree = Engine.get_main_loop()
	if tree is SceneTree and not tree.is_connected("node_added", self, "_on_node_added"):
		var _err = tree.connect("node_added", self, "_on_node_added")


func onFoxLibModInit(foxModuleAPI):
	var option = foxModuleAPI.addListOptionInCategory(CATEGORY, "mode", "Clip fur", [
			[MODE_OFF, "Off"], [MODE_CLOTHED, "Under clothing (recommended)"], [MODE_ALWAYS, "Always"],
		], "Cuts fur that sticks out of the normal body outline, so it doesn't poke through clothes.\n"
		+ "Under clothing = only bodyparts covered by worn clothing, Always = also when naked.\n"
		+ "Needs the advanced shaders option (on by default).", MODE_CLOTHED)
	var _err = option.connect("option_changed", self, "_on_mode_changed")

	var button = foxModuleAPI.addButtonOptionInCategory(CATEGORY, "preview", "Preview",
		"Shows a fur body with clothing side by side, without and with the clipping.")
	_err = button.connect("option_changed", self, "_on_preview_pressed")


func _on_preview_pressed(_value) -> void:
	var tree = Engine.get_main_loop()
	if not tree is SceneTree:
		return
	var window = PREVIEW_WINDOW.new()
	window.module = self
	tree.root.add_child(window)


func _on_mode_changed(_value) -> void:
	var tree = Engine.get_main_loop()
	if not tree is SceneTree:
		return
	for mesh in tree.get_nodes_in_group(MESH_GROUP):
		var doll = mesh.getDoll()
		if doll != null and is_instance_valid(doll):
			_queue_doll(doll)


func _on_node_added(node: Node) -> void:
	if node is MeshInstanceWithPattern:
		_remember_mask(node)
	# Doll3D.addPartObject(): part.setDoll3d(doll), then skeleton.add_child(part)
	elif node.has_method("initPart") and node.get_parent() is Skeleton:
		_watch_part(node)


# Runs before the mesh's _ready() replaces its material, the vanilla texture is still there
func _remember_mask(mesh) -> void:
	if mesh.has_meta(META_MASK):
		return
	var vanilla = find_mask(mesh)
	if vanilla != null:
		mesh.set_meta(META_MASK, vanilla)
		mesh.add_to_group(MESH_GROUP)


# The vanilla texture under a mod's customAlbedo, null if the mesh has no own fur texture
static func find_mask(mesh):
	if mesh.customAlbedo == null:
		return null
	var material = mesh.get_surface_material(0)
	if not material is SpatialMaterial and mesh.mesh != null and mesh.mesh.get_surface_count() > 0:
		material = mesh.mesh.surface_get_material(0)
	if not material is SpatialMaterial:
		return null
	var vanilla = material.albedo_texture
	if vanilla == null or vanilla == mesh.customAlbedo:
		return null
	return vanilla


func _watch_part(part: Node) -> void:
	var doll = part.get("doll3D")
	if doll == null or not is_instance_valid(doll):
		return
	_queue_doll(doll)
	var doll_ref = weakref(doll)
	# Doll3D.updateAlpha() shows and hides clothing without adding or removing parts
	for signal_name in ["tree_exited", "visibility_changed"]:
		if not part.is_connected(signal_name, self, "_on_part_changed"):
			var _err = part.connect(signal_name, self, "_on_part_changed", [doll_ref])


func _on_part_changed(doll_ref: WeakRef) -> void:
	var doll = doll_ref.get_ref()
	if doll != null and is_instance_valid(doll):
		_queue_doll(doll)


# Doll3D.setParts() adds and removes several parts in a row, update once afterwards
func _queue_doll(doll: Node) -> void:
	if _pending_dolls.empty():
		call_deferred("_update_pending_dolls")
	_pending_dolls[doll.get_instance_id()] = weakref(doll)


func _update_pending_dolls() -> void:
	var dolls = _pending_dolls.values()
	_pending_dolls.clear()
	for doll_ref in dolls:
		var doll = doll_ref.get_ref()
		if doll != null and is_instance_valid(doll) and doll.is_inside_tree():
			_update_doll(doll)


func _update_doll(doll: Node) -> void:
	var parts = doll.get("parts")
	if not parts is Dictionary:
		return
	var doll_mode = int(doll.get_meta(META_MODE)) if doll.has_meta(META_MODE) else int(mode)
	var clothing_slots = _get_clothing_slots(doll, parts)
	var covered_bones := {}
	var clothing_meshes := [] # [MeshInstance, its texture]
	for slot in clothing_slots:
		var part = parts[slot]
		if not is_instance_valid(part) or not part.visible:
			continue
		for mesh in _collect_meshes(part):
			if not mesh.visible:
				continue # alternative state of the part, e.g. another breast size
			var shares = _get_bone_shares(mesh)
			for bone in shares:
				if shares[bone] >= CLOTHING_BONE_SHARE:
					covered_bones[bone] = true
			var texture = _get_mesh_texture(mesh)
			if texture != null:
				clothing_meshes.append([mesh, texture])

	for slot in parts:
		var part = parts[slot]
		if slot in clothing_slots or not is_instance_valid(part):
			continue
		for mesh in _collect_meshes(part):
			if mesh.has_meta(META_MASK):
				_apply_to_mesh(mesh, doll_mode, covered_bones, clothing_meshes)


# Doll parts added by the equipped items (clothes, underwear, restraints). Without a character
# (previews), every part that isn't in a bodypart slot counts.
static func _get_clothing_slots(doll: Node, parts: Dictionary) -> Array:
	var result := []
	var character_id = doll.get("savedCharacterID")
	var character = null
	if character_id != null and not (character_id is String and character_id == ""):
		character = doll.getCharFromID(character_id)
	if character != null and is_instance_valid(character) and character.has_method("getInventory"):
		var equipped_items = character.getInventory().getAllEquippedItems()
		for inventory_slot in equipped_items:
			var rigged = equipped_items[inventory_slot].getRiggedParts(character)
			if not rigged is Dictionary:
				continue
			for zone in rigged:
				if parts.has(zone) and not zone in result:
					result.append(zone)
		return result

	var bodypart_slots = BodypartSlot.getAll()
	for slot in parts:
		if not slot in bodypart_slots:
			result.append(slot)
	return result


func _apply_to_mesh(mesh: MeshInstance, doll_mode: int, covered_bones: Dictionary,
		clothing_meshes: Array) -> void:
	var material = mesh.get_surface_material(0)
	if not material is ShaderMaterial:
		return # advanced shaders off: customAlbedo isn't used at all
	var current = material.get_shader_param("texture_albedo")
	# Remember the fur texture, again if another mod has switched it since
	if not mesh.has_meta(META_FUR) or (current != mesh.get_meta(META_FUR)
			and not _clipped_textures.has(current)):
		mesh.set_meta(META_FUR, current)
	var fur = mesh.get_meta(META_FUR)
	if not fur is Texture:
		return

	var mask = mesh.get_meta(META_MASK)
	var clipped = null
	if doll_mode == MODE_ALWAYS:
		clipped = _get_clipped_texture(fur, mask)
	elif doll_mode == MODE_CLOTHED:
		# Clothing drawn on the same mesh (same UVs) covers exactly where its texture is opaque,
		# other clothing on the same bones counts as covering the whole mesh
		var cover_textures = []
		for entry in clothing_meshes:
			if _same_geometry(mesh, entry[0]):
				cover_textures.append(entry[1])
		if not cover_textures.empty():
			clipped = _get_region_texture(fur, mask, cover_textures)
		elif _is_covered(mesh, covered_bones):
			clipped = _get_clipped_texture(fur, mask)
	var wanted = clipped if clipped != null else fur
	if current != wanted:
		material.set_shader_param("texture_albedo", wanted)


static func _get_mesh_texture(mesh: MeshInstance):
	var material = mesh.get_surface_material(0)
	if material == null and mesh.mesh.get_surface_count() > 0:
		material = mesh.mesh.surface_get_material(0)
	if material is SpatialMaterial:
		return material.albedo_texture
	if material is ShaderMaterial:
		var texture = material.get_shader_param("texture_albedo")
		if texture is Texture:
			return texture
	return null


# Clothing is usually made from a copy of the bodypart's mesh: same vertices, same UV layout
static func _same_geometry(a: MeshInstance, b: MeshInstance) -> bool:
	if a.mesh.get_surface_count() < 1 or b.mesh.get_surface_count() < 1:
		return false
	if a.mesh.surface_get_array_len(0) != b.mesh.surface_get_array_len(0):
		return false
	var box_a = a.mesh.get_aabb()
	var box_b = b.mesh.get_aabb()
	return (abs(box_a.position.x - box_b.position.x) < GEOMETRY_TOLERANCE
			and abs(box_a.position.y - box_b.position.y) < GEOMETRY_TOLERANCE
			and abs(box_a.end.x - box_b.end.x) < GEOMETRY_TOLERANCE
			and abs(box_a.end.y - box_b.end.y) < GEOMETRY_TOLERANCE)


func _is_covered(mesh: MeshInstance, covered_bones: Dictionary) -> bool:
	var shares = _get_bone_shares(mesh)
	for bone in shares:
		if shares[bone] >= FUR_BONE_SHARE and covered_bones.has(bone):
			return true
	return false


static func _collect_meshes(part: Node) -> Array:
	var result := []
	var stack := [part]
	while not stack.empty():
		var node = stack.pop_back()
		if node is MeshInstance and node.mesh != null:
			result.append(node)
		for child in node.get_children():
			stack.append(child)
	return result


# Share of the skin weights per bone name, summed over all surfaces of the mesh
func _get_bone_shares(mesh_instance: MeshInstance) -> Dictionary:
	var mesh = mesh_instance.mesh
	var skin = mesh_instance.skin
	var key = str(mesh.get_instance_id()) + "|" + (str(skin.get_instance_id()) if skin != null else "")
	if _bone_cache.has(key):
		return _bone_cache[key]

	var weights_by_index := {}
	var total := 0.0
	for surface in range(mesh.get_surface_count()):
		var arrays = mesh.surface_get_arrays(surface)
		if (arrays.size() <= Mesh.ARRAY_WEIGHTS or arrays[Mesh.ARRAY_BONES] == null
				or arrays[Mesh.ARRAY_WEIGHTS] == null):
			continue
		var bones = arrays[Mesh.ARRAY_BONES]
		var weights = arrays[Mesh.ARRAY_WEIGHTS]
		for i in range(int(min(bones.size(), weights.size()))):
			var bone = int(bones[i])
			weights_by_index[bone] = weights_by_index.get(bone, 0.0) + float(weights[i])
			total += float(weights[i])

	var result := {}
	var skeleton = mesh_instance.get_node_or_null(mesh_instance.skeleton)
	if total > 0.0:
		for bone in weights_by_index:
			var bone_name = _get_bone_name(skin, skeleton, bone)
			if bone_name != "":
				result[bone_name] = result.get(bone_name, 0.0) + weights_by_index[bone] / total
	# Not cached before the part is attached to the doll's skeleton (no names yet)
	if skeleton is Skeleton or skin != null:
		_bone_cache[key] = result
	return result


# Bone indices point into the skin binds, or straight into the skeleton without a skin
static func _get_bone_name(skin, skeleton, bone: int) -> String:
	if skin != null and bone < skin.get_bind_count():
		var bind_name = skin.get_bind_name(bone)
		if bind_name != "":
			return bind_name
		var bind_bone = skin.get_bind_bone(bone) # -1 for binds by name
		if skeleton is Skeleton and bind_bone >= 0 and bind_bone < skeleton.get_bone_count():
			return skeleton.get_bone_name(bind_bone)
		return ""
	if skeleton is Skeleton and bone < skeleton.get_bone_count():
		return skeleton.get_bone_name(bone)
	return ""


### Clipped textures
# Results are kept in memory and as PNG files in CACHE_DIR, so they are computed once per
# combination of textures, not once per game start. The file names come from hashes of the pixels,
# so an updated mod with changed textures gets new files instead of stale ones.

func _get_clipped_texture(fur: Texture, mask: Texture):
	var key = _texture_hash(fur) + "|" + _texture_hash(mask)
	if not _clipped_cache.has(key):
		var image = _load_cached_image(key)
		if image is bool:
			image = _create_clipped_image(fur, mask)
			_save_cached_image(key, image)
		_clipped_cache[key] = _make_texture(image, fur)
	return _clipped_cache[key]


func _get_region_texture(fur: Texture, mask: Texture, cover_textures: Array):
	var full = _get_clipped_texture(fur, mask)
	if full == null:
		return null
	var cover_hashes = []
	for texture in cover_textures:
		cover_hashes.append(_texture_hash(texture))
	cover_hashes.sort()
	var key = (_texture_hash(fur) + "|" + _texture_hash(mask) + "|"
			+ PoolStringArray(cover_hashes).join("+"))
	if not _clipped_cache.has(key):
		var image = _load_cached_image(key)
		if image is bool:
			image = _create_region_image(fur, full.get_data(), mask, cover_textures)
			_save_cached_image(key, image)
		_clipped_cache[key] = _make_texture(image, fur)
	return _clipped_cache[key]


func _make_texture(image, fur: Texture):
	if image == null:
		return null
	var texture = ImageTexture.new()
	texture.create_from_image(image, fur.flags)
	_clipped_textures[texture] = true
	return texture


func _texture_hash(texture: Texture) -> String:
	var key = _texture_key(texture)
	if not _texture_hashes.has(key):
		var image = _get_rgba_image(texture)
		var context = HashingContext.new()
		var _err = context.start(HashingContext.HASH_MD5)
		if image != null:
			_err = context.update(image.get_data())
			_err = context.update(var2bytes(image.get_size()))
		_texture_hashes[key] = context.finish().hex_encode()
	return _texture_hashes[key]


static func _cache_path(key: String) -> String:
	return CACHE_DIR + (str(CACHE_VERSION) + "|" + key).md5_text()


# Returns the cached Image, null if the combination can't be clipped, false if not cached yet
static func _load_cached_image(key: String):
	var path = _cache_path(key)
	var file = File.new()
	if file.file_exists(path + ".none"):
		return null
	if not file.file_exists(path + ".png"):
		return false
	var image = Image.new()
	if image.load(path + ".png") != OK:
		return false
	image.convert(Image.FORMAT_RGBA8)
	return image


func _save_cached_image(key: String, image) -> void:
	if not _cache_dir_checked:
		_cache_dir_checked = true
		_prepare_cache_dir()
	var path = _cache_path(key)
	if image == null:
		var file = File.new()
		if file.open(path + ".none", File.WRITE) == OK:
			file.close()
	elif image.save_png(path + ".png") != OK:
		printerr("FurUnderClothing: can't write " + path + ".png")


static func _prepare_cache_dir() -> void:
	var dir = Directory.new()
	if not dir.dir_exists(CACHE_DIR) and dir.make_dir_recursive(CACHE_DIR) != OK:
		return
	var version_path = CACHE_DIR + "version.txt"
	var file = File.new()
	var version = ""
	if file.open(version_path, File.READ) == OK:
		version = file.get_as_text().strip_edges()
		file.close()
	var names = []
	if dir.open(CACHE_DIR) == OK and dir.list_dir_begin(true) == OK:
		var file_name = dir.get_next()
		while file_name != "":
			if file_name != "version.txt":
				names.append(file_name)
			file_name = dir.get_next()
		dir.list_dir_end()
	if version != str(CACHE_VERSION) or names.size() > CACHE_MAX_FILES:
		for file_name in names:
			var _err = dir.remove(CACHE_DIR + file_name)
		if file.open(version_path, File.WRITE) == OK:
			file.store_string(str(CACHE_VERSION))
			file.close()


static func _create_region_image(fur: Texture, full_image: Image, mask: Texture,
		cover_textures: Array):
	var result = _get_rgba_image(fur)
	if result == null or full_image == null:
		return null
	full_image.convert(Image.FORMAT_RGBA8)
	var size = result.get_size()
	var rect = Rect2(Vector2.ZERO, size)

	var cover = Image.new()
	cover.create(int(size.x), int(size.y), false, Image.FORMAT_RGBA8)
	for texture in cover_textures:
		var image = _get_rgba_image(texture)
		if image != null:
			image.resize(int(size.x), int(size.y), Image.INTERPOLATE_BILINEAR)
			cover.blend_rect(image, rect, Vector2.ZERO)
	var used = cover.get_used_rect()
	if used.size.x <= 0 or used.size.y <= 0:
		return null # the clothing leaves this bodypart uncovered

	# BitMap.grow_mask() costs radius² per pixel, so the region is grown at a quarter of the size
	var grow = int(max(1.0, round(COVER_GROW * size.x / mask.get_width())))
	var small = cover.duplicate()
	small.resize(int(ceil(size.x / REGION_SCALE)), int(ceil(size.y / REGION_SCALE)),
			Image.INTERPOLATE_BILINEAR)
	var region = BitMap.new()
	region.create_from_image_alpha(small, 0.1)
	var small_grow = int(ceil(float(grow) / REGION_SCALE))
	region.grow_mask(small_grow, Rect2(Vector2.ZERO, small.get_size()))
	used = used.grow(grow + REGION_SCALE).clip(rect)

	result.lock()
	full_image.lock()
	for y in range(int(used.position.y), int(used.end.y)):
		for x in range(int(used.position.x), int(used.end.x)):
			if region.get_bit(Vector2(x / REGION_SCALE, y / REGION_SCALE)):
				result.set_pixel(x, y, full_image.get_pixel(x, y))
	full_image.unlock()
	result.unlock()
	return result


static func _texture_key(texture: Texture) -> String:
	if texture.resource_path != "":
		return texture.resource_path
	return str(texture.get_instance_id())


# Inside the vanilla shape (shrunk by the outline width) the fur texture is kept as it is.
# In the outline band the vanilla pixels are used where the fur covers them, so the cut gets the
# vanilla outline, but no second line appears where the fur is narrower than the vanilla shape.
# Outside the vanilla shape everything is cut.
# Returns null if the textures can't be read or the mask doesn't have the fur's shape.
static func _create_clipped_image(fur: Texture, mask: Texture):
	var names = _texture_key(fur) + " with mask " + _texture_key(mask)
	var fur_image = _get_rgba_image(fur)
	var mask_image = _get_rgba_image(mask)
	if fur_image == null or mask_image == null:
		printerr("FurUnderClothing: can't read " + names)
		return null

	var size = fur_image.get_size()
	var mask_size = mask_image.get_size()
	if abs(size.x / size.y - mask_size.x / mask_size.y) > MAX_ASPECT_DIFFERENCE:
		print("FurUnderClothing: not clipping " + names + ", different aspect ratio")
		return null
	mask_image.resize(int(size.x), int(size.y), Image.INTERPOLATE_BILINEAR)
	var rect = Rect2(Vector2.ZERO, size)

	var outer = BitMap.new()
	outer.create_from_image_alpha(mask_image, 0.05)
	var inner = BitMap.new()
	inner.create_from_image_alpha(mask_image, 0.5)
	inner.grow_mask(-int(max(1.0, round(EDGE_WIDTH * size.x / mask_size.x))), rect)
	var fur_bits = BitMap.new()
	fur_bits.create_from_image_alpha(fur_image, 0.5)

	var result = Image.new()
	result.create(int(size.x), int(size.y), false, Image.FORMAT_RGBA8)
	var used = mask_image.get_used_rect() # nothing to copy outside the vanilla shape
	var kept := 0
	result.lock()
	fur_image.lock()
	mask_image.lock()
	for y in range(int(used.position.y), int(used.end.y)):
		for x in range(int(used.position.x), int(used.end.x)):
			var pos = Vector2(x, y)
			if not outer.get_bit(pos):
				continue
			if fur_bits.get_bit(pos):
				kept += 1
			if inner.get_bit(pos):
				result.set_pixel(x, y, fur_image.get_pixel(x, y))
			elif fur_bits.get_bit(pos):
				result.set_pixel(x, y, mask_image.get_pixel(x, y))
	mask_image.unlock()
	fur_image.unlock()
	result.unlock()

	var fur_count = fur_bits.get_true_bit_count()
	if fur_count == 0 or float(kept) / fur_count < MIN_KEPT_SHARE:
		print("FurUnderClothing: not clipping " + names + ", mask doesn't match the fur's shape")
		return null
	_keep_extra_fur(result, fur, fur_image, fur_bits)
	return result


static func _keep_extra_fur(result: Image, fur: Texture, fur_image: Image,
		fur_bits: BitMap) -> void:
	var reference_path = KEEP_EXTRA_FUR.get(fur.resource_path.get_file())
	if reference_path == null or not ResourceLoader.exists(reference_path):
		return
	var reference = _get_rgba_image(load(reference_path))
	if reference == null or reference.get_size() != fur_image.get_size():
		return
	var size = fur_image.get_size()
	var reference_bits = BitMap.new()
	reference_bits.create_from_image_alpha(reference, 0.5)
	var keep = BitMap.new()
	keep.create(size)
	for y in range(int(size.y)):
		for x in range(int(size.x)):
			var pos = Vector2(x, y)
			if fur_bits.get_bit(pos) and not reference_bits.get_bit(pos):
				keep.set_bit(pos, true)
	keep.grow_mask(KEEP_GROW, Rect2(Vector2.ZERO, size))
	result.lock()
	fur_image.lock()
	for y in range(int(size.y)):
		for x in range(int(size.x)):
			if keep.get_bit(Vector2(x, y)):
				result.set_pixel(x, y, fur_image.get_pixel(x, y))
	fur_image.unlock()
	result.unlock()


static func _get_rgba_image(texture: Texture):
	var image = texture.get_data()
	if image == null or image.is_empty():
		return null
	image = image.duplicate()
	if image.is_compressed():
		var err = image.decompress()
		if err != OK:
			return null
	image.convert(Image.FORMAT_RGBA8)
	return image
