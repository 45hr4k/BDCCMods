extends Module

# "Check mod conflicts" button in the troubleshooting screen of the main menu.
# Mods are loaded before the main menu, so everything is checked against the mods that are loaded
# right now. If the troubleshooting screen ever changes, the button goes to the main menu instead.

const ConflictChecker := preload("res://Modules/ModConflictCheck/conflict_checker.gd")
const REPORT_PATH := "user://modConflictReport.txt"
const TROUBLESHOOTING_BUTTONS := "MainHBox/CenterContainer/VBoxContainer"
const BUTTON_TEXT := "Check mod conflicts"
const BUTTON_HINT := ("Find mods that overwrite each other or the game's files "
		+ "(e.g. missing body parts)")

var _added_to_troubleshooting := false
var _panel: PanelContainer
var _label: RichTextLabel
var _save_button: Button
var _report_text := ""
var _checking := false


func _init() -> void:
	id = "ModConflictCheck"
	author = "45hr4k"
	var tree := Engine.get_main_loop()
	if tree is SceneTree and not tree.is_connected("node_added", self, "_on_node_added"):
		var _err := tree.connect("node_added", self, "_on_node_added")


# The main menu asks for its buttons after its troubleshooting screen entered the tree
func getMenuButtons() -> Array:
	if _added_to_troubleshooting:
		return []
	return [menuButton("check", BUTTON_TEXT, BUTTON_HINT)]


func onMenuButton(_button_id: String, menu_scene) -> void:
	_show_report(menu_scene)


func _on_node_added(node: Node) -> void:
	if node.name != "TroubleshootingScreen":
		return
	var buttons := node.get_node_or_null(TROUBLESHOOTING_BUTTONS)
	if buttons == null:
		return
	_added_to_troubleshooting = true
	var check_button := Button.new()
	check_button.text = BUTTON_TEXT
	check_button.hint_tooltip = BUTTON_HINT
	check_button.rect_min_size = Vector2(0, 50)
	check_button.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var _err := check_button.connect("pressed", self, "_show_report", [node])
	# Deferred: the screen is still being added to the tree right now
	buttons.call_deferred("add_child", check_button)
	var close_button := buttons.get_node_or_null("CloseButton")
	if close_button != null:
		buttons.call_deferred("move_child", check_button, close_button.get_index())


func _show_report(parent: Node) -> void:
	if not is_instance_valid(_panel) or _panel.get_parent() != parent:
		if is_instance_valid(_panel):
			_panel.queue_free()
		_create_panel(parent)
	_panel.visible = true
	if _checking:
		return
	var checker := ConflictChecker.new()
	if _report_text.empty(): # mods only load at start, so one check per session is enough
		_checking = true
		_label.bbcode_text = "Checking mods.."
		_save_button.disabled = true
		var tree: SceneTree = Engine.get_main_loop()
		yield(tree, "idle_frame")
		yield(tree, "idle_frame")
		_report_text = checker.make_report()
		_checking = false
	if not is_instance_valid(_label): # the screen was closed meanwhile
		return
	_save_button.disabled = false
	_label.bbcode_text = checker.to_bbcode(_report_text)
	_label.scroll_to_line(0)


func _create_panel(parent: Node) -> void:
	_panel = PanelContainer.new()
	_panel.set_anchors_and_margins_preset(Control.PRESET_WIDE)
	parent.add_child(_panel)

	var vbox := VBoxContainer.new()
	_panel.add_child(vbox)

	_label = RichTextLabel.new()
	_label.bbcode_enabled = true
	_label.selection_enabled = true
	_label.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(_label)

	_save_button = Button.new()
	_save_button.text = "Save report to a file and open it"
	_save_button.rect_min_size = Vector2(0, 50)
	var _err := _save_button.connect("pressed", self, "_on_save_pressed")
	vbox.add_child(_save_button)

	var close_button := Button.new()
	close_button.text = "Close"
	close_button.rect_min_size = Vector2(0, 50)
	_err = close_button.connect("pressed", self, "_on_close_pressed")
	vbox.add_child(close_button)


func _on_save_pressed() -> void:
	Util.writeFile(REPORT_PATH, _report_text)
	var _err = Util.fixed_shell_open(ProjectSettings.globalize_path(REPORT_PATH))


func _on_close_pressed() -> void:
	_panel.visible = false
