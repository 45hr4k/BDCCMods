extends Reference

# Finds out which mod breaks which. Runs in the main menu, after the mods are loaded.
# Files: reads the zips of the loaded mods (in the order they were loaded) and the file list of the
#   game's own .pck (the mods are mounted into res:// already, so res:// can't tell them apart).
# IDs: loads every script of the game and the mods that extends one of the registered base classes
#   (Bodypart, ItemBase, ...) and compares its id with the script registered under that id now.
#   BDCC sets the ids in _init(), so the scripts have to be instanced to read them.

const MOD_ORDER_PATH := "user://modOrder.json"
const PCK_MAGIC := 0x43504447
const IGNORED_FILES := [
	"license", "license.txt", "license.md", "readme", "readme.txt", "readme.md",
	"changelog.md", "changelog.txt",
]

var _base_files := {} # res:// path -> true, empty if the game's .pck couldn't be read
var _mod_files := {} # res:// path -> [mod file name, ...] in load order
var _unreadable_mods := []
var _mod_count := 0


func make_report() -> String:
	_read_mod_files()
	var has_base_files := _read_base_files()

	var conflicts := []
	var base_overrides := []
	var sorted_paths := _mod_files.keys()
	sorted_paths.sort()
	for res_path in sorted_paths:
		# Imported copies, already listed under their source file
		if res_path.begins_with("res://.import/"):
			continue
		if _mod_files[res_path].size() > 1:
			conflicts.append(res_path)
		elif _base_files.has(res_path):
			base_overrides.append(res_path)

	var text := "Game version: %s, loaded mods: %d, files in them: %d\n" % [
			GlobalRegistry.getGameVersionString(), _mod_count, _mod_files.size()]

	text += ("\n1. FILES SHIPPED BY MORE THAN ONE MOD "
			+ "(only the mod loaded last wins, the other mod is partially broken)\n")
	if conflicts.empty():
		text += "None\n"
	for res_path in conflicts:
		var owners: Array = _mod_files[res_path]
		text += "CONFLICT%s %s\n" % [_doll_tag(res_path), res_path]
		text += "    mods: %s  ->  used: %s\n" % [PoolStringArray(owners).join(", "), owners.back()]

	text += ("\n2. BASE GAME FILES REPLACED BY A MOD (OK if the mod is made for this game version, "
			+ "otherwise a common cause of missing body parts)\n")
	if not has_base_files:
		text += "Can't read the file list of the game's .pck, skipped.\n"
	elif base_overrides.empty():
		text += "None\n"
	for res_path in base_overrides:
		text += "REPLACES%s %s  <-  %s\n" % [_doll_tag(res_path), res_path, _mod_files[res_path][0]]

	if not _unreadable_mods.empty():
		text += ("\nCan't look inside these (.pck) mods: %s\n"
				% PoolStringArray(_unreadable_mods).join(", "))

	var script_issues := _check_scripts()

	text += "\n3. SAME ID REGISTERED TWICE (the second one replaces the first)\n"
	if script_issues.replaced.empty():
		text += "None\n"
	for issue in script_issues.replaced:
		text += "  %s '%s'\n" % [issue.kind, issue.id]
		text += "     replaced: %s%s\n" % [issue.old, _describe_source(issue.old)]
		text += "     by:       %s%s\n" % [issue.new, _describe_source(issue.new)]

	text += ("\n4. SCRIPTS THAT FAIL TO LOAD "
			+ "(the thing is missing in game, check godot.log for the exact error)\n")
	if script_issues.broken.empty():
		text += "None\n"
	for res_path in script_issues.broken:
		text += "  ERROR %s%s\n" % [res_path, _describe_source(res_path)]

	text += "\n5. BODYPARTS WITH A MISSING DOLL SCENE (invisible on the doll)\n"
	var missing_doll := _check_doll_scenes()
	if missing_doll.empty():
		text += "None\n"
	for issue in missing_doll:
		text += "  ERROR bodypart '%s' %s%s\n" % [issue.id, issue.path, _describe_source(issue.path)]
		text += "        wants: %s  (this file exists neither in the game nor in a mod)\n" % issue.scene
	return text


# Colors for the report window, everything else is escaped
func to_bbcode(text: String) -> String:
	var lines := PoolStringArray()
	for line in text.replace("[", "[lb]").split("\n"):
		if line.begins_with("CONFLICT") or line.strip_edges().begins_with("ERROR"):
			line = "[color=red]%s[/color]" % line
		elif line.begins_with("REPLACES"):
			line = "[color=yellow]%s[/color]" % line
		elif line == "None":
			line = "[color=green]None[/color]"
		elif line.length() > 2 and line[0].is_valid_integer() and line[1] == ".":
			line = "[b]%s[/b]" % line
		lines.append(line)
	return lines.join("\n")


func _doll_tag(res_path: String) -> String:
	if (res_path.begins_with("res://Player/Player3D/")
			or res_path.begins_with("res://Player/Bodyparts/")):
		return " [DOLL]"
	return ""


func _describe_source(res_path: String) -> String:
	if res_path == "":
		return "  (script created while loading, e.g. from a WintersCore template)"
	if _mod_files.has(res_path):
		return "  (mod: %s)" % PoolStringArray(_mod_files[res_path]).join(", ")
	return "  (base game)"


# Loaded mods in the order they were loaded. modOrder.json only gives the paths: it can have
# changed since the start (launcher, mod browser).
func _read_mod_files() -> void:
	var paths := {} # file name -> path
	var json_result := JSON.parse(Util.readFile(MOD_ORDER_PATH))
	if json_result.error == OK and json_result.result is Array:
		for mod_entry in json_result.result:
			if mod_entry is Dictionary and mod_entry.has("path"):
				paths[str(mod_entry["path"]).get_file()] = str(mod_entry["path"])
	for mod_name in GlobalRegistry.getLoadedMods():
		var mod_path: String = paths.get(mod_name, GlobalRegistry.getModsFolder().plus_file(mod_name))
		_mod_count += 1
		if mod_path.get_extension() != "zip":
			_unreadable_mods.append(mod_name)
			continue
		for file_path in _get_zip_files(mod_path):
			var res_path: String = "res://" + file_path
			if not _mod_files.has(res_path):
				_mod_files[res_path] = []
			_mod_files[res_path].append(mod_name)


func _get_zip_files(mod_path: String) -> Array:
	var result := []
	var gdunzip = GDUnzip.new()
	if not gdunzip.load(mod_path) or gdunzip.files == null:
		return result
	for file_path in gdunzip.files:
		# Root files are the mod's own JSON (named like the mod, not like the zip) and readmes
		if file_path.ends_with("/") or not "/" in file_path:
			continue
		if file_path.get_file().to_lower() in IGNORED_FILES:
			continue
		result.append(file_path)
	return result


func _read_base_files() -> bool:
	var exe_path := OS.get_executable_path()
	for pck_path in [exe_path.get_basename() + ".pck", "user://BDCC.pck"]:
		if _read_pck_index(pck_path, false):
			return true
	return _read_pck_index(exe_path, true) # .pck embedded in the exe


func _read_pck_index(pck_path: String, embedded: bool) -> bool:
	var file := File.new()
	if not file.file_exists(pck_path) or file.open(pck_path, File.READ) != OK:
		return false
	var start := 0
	if embedded: # ... pck data, u64 pck size, u32 magic
		file.seek_end(-12)
		var pck_size := file.get_64()
		if file.get_32() != PCK_MAGIC:
			file.close()
			return false
		start = file.get_len() - 12 - pck_size
	file.seek(start)
	if file.get_32() != PCK_MAGIC:
		file.close()
		return false
	file.seek(start + 4 * 21) # magic, pack version, godot version (3), reserved (16)
	var count := file.get_32()
	for _i in range(count):
		if file.get_position() + 4 > file.get_len(): # damaged or unknown .pck layout
			break
		var bytes := file.get_buffer(file.get_32())
		while bytes.size() > 0 and bytes[bytes.size() - 1] == 0:
			bytes.remove(bytes.size() - 1)
		var res_path := bytes.get_string_from_utf8()
		for suffix in [".import", ".remap"]:
			if res_path.ends_with(suffix):
				res_path = res_path.trim_suffix(suffix)
		_base_files[res_path] = true
		file.seek(file.get_position() + 32) # offset, size, md5
	file.close()
	return not _base_files.empty()


func _get_categories() -> Array:
	return [
		{kind = "bodypart", base = Bodypart, registry = GlobalRegistry.bodyparts},
		{kind = "attack", base = Attack, registry = GlobalRegistry.attacks},
		{kind = "statusEffect", base = StatusEffectBase, registry = GlobalRegistry.statusEffects},
		{kind = "species", base = Species, registry = GlobalRegistry.allSpecies},
		{kind = "item", base = ItemBase, registry = GlobalRegistry.items},
		{kind = "inventorySlot", base = CustomInventorySlot, registry = GlobalRegistry.inventorySlots},
		{kind = "bodypartSlot", base = CustomBodypartSlot, registry = GlobalRegistry.bodypartSlots},
		{kind = "buff", base = BuffBase, registry = GlobalRegistry.buffs},
		{kind = "event", base = EventBase, registry = GlobalRegistry.events},
		{kind = "perk", base = PerkBase, registry = GlobalRegistry.perks},
		{kind = "sexActivity", base = SexActivityBase, registry = GlobalRegistry.sexActivities},
		{kind = "skin", base = SkinBase, registry = GlobalRegistry.skins},
		{kind = "partSkin", base = PartSkinBase, registry = _flatten_part_skins()},
	]


func _flatten_part_skins() -> Dictionary:
	var result := {}
	for part_id in GlobalRegistry.partSkins:
		for skin_id in GlobalRegistry.partSkins[part_id]:
			result[str(part_id) + "/" + str(skin_id)] = GlobalRegistry.partSkins[part_id][skin_id]
	return result


# {replaced = [{kind, id, old, new}], broken = [res_path]}
func _check_scripts() -> Dictionary:
	var result := {replaced = [], broken = []}
	var categories := _get_categories()
	for category in categories:
		category.winners = {}
		for registered_id in category.registry:
			category.winners[str(registered_id)] = _get_script_path(category.registry[registered_id])
		category.default_id = _get_id(category.base, category.kind)

	# The game registers all its scripts. Mods often ship compatibility scripts for other mods
	# that are only used when that mod is installed, and variants they pick from themselves.
	# Scripts listed in a module are registered for sure; the others are checked more carefully below.
	var listed_scripts := _get_listed_scripts()
	var script_paths := []
	for res_path in _base_files:
		if (res_path.ends_with(".gd") and not res_path.begins_with("res://addons/")
				and not _mod_files.has(res_path)):
			script_paths.append(res_path)
	for res_path in _mod_files:
		if res_path.ends_with(".gd"):
			script_paths.append(res_path)
	script_paths.sort()

	for res_path in script_paths:
		var is_mod_script: bool = _mod_files.has(res_path)
		var is_listed: bool = listed_scripts.has(res_path)
		if is_mod_script and not is_listed and _extends_missing_file(res_path):
			continue # compatibility script for a mod that isn't installed
		var script = load(res_path)
		if script == null or not script is Script or not script.can_instance():
			if is_mod_script:
				result.broken.append(res_path)
			continue
		var category = _find_category(script, categories)
		if category == null:
			continue
		var script_id := _get_id(script, category.kind)
		if script_id == "" or script_id == category.default_id or not category.winners.has(script_id):
			continue # not registered under its own id, e.g. a shared parent class
		var winner_path: String = category.winners[script_id]
		if winner_path == res_path:
			continue
		if (is_mod_script and not is_listed
				and (winner_path == "" or _from_same_mod(res_path, winner_path))):
			continue # the mod picked one of its own variants
		result.replaced.append({kind = category.kind, id = script_id, old = res_path, new = winner_path})
	return result


func _from_same_mod(path_a: String, path_b: String) -> bool:
	for mod_name in _mod_files.get(path_a, []):
		if mod_name in _mod_files.get(path_b, []):
			return true
	return false


# True if the script extends "res://..." and that file (or one further up) doesn't exist
func _extends_missing_file(res_path: String, depth: int = 0) -> bool:
	if depth > 10:
		return false
	var file := File.new()
	if file.open(res_path, File.READ) != OK:
		return false
	var regex := RegEx.new()
	var _err := regex.compile("^\\s*extends\\s+\"(res://[^\"]+)\"")
	var result := false
	while not file.eof_reached():
		var line := file.get_line()
		var found := regex.search(line)
		if found != null:
			var parent_path := found.get_string(1)
			result = not ResourceLoader.exists(parent_path) or _extends_missing_file(parent_path, depth + 1)
			break
		if line.strip_edges().begins_with("func "):
			break
	file.close()
	return result


# Script paths in the lists of all modules (bodyparts, items, species, ...)
func _get_listed_scripts() -> Dictionary:
	var result := {}
	var modules: Dictionary = GlobalRegistry.getModules()
	for module_id in modules:
		var module = modules[module_id]
		for property in module.get_property_list():
			if property.type != TYPE_ARRAY:
				continue
			for entry in module.get(property.name):
				if entry is String and entry.ends_with(".gd"):
					result[entry] = true
	return result


func _find_category(script: Script, categories: Array):
	var current := script.get_base_script()
	while current != null:
		for category in categories:
			if current == category.base:
				return category
		current = current.get_base_script()
	return null


func _get_id(script: Script, kind: String) -> String:
	var object = script.new()
	if object == null:
		return ""
	var result := str(object.id)
	if kind == "partSkin":
		result = str(object.partID) + "/" + result
	if object is Node:
		object.free()
	return result


func _get_script_path(registered) -> String:
	if registered is Script:
		return registered.resource_path
	if registered is Object and registered.get_script() != null:
		return registered.get_script().resource_path
	return ""


func _check_doll_scenes() -> Array:
	var result := []
	for bodypart_id in GlobalRegistry.bodyparts:
		var bodypart = GlobalRegistry.bodyparts[bodypart_id]
		var part_scene = bodypart.getDoll3DScene()
		if not part_scene is String or part_scene == "":
			continue
		if not ResourceLoader.exists(part_scene):
			result.append({id = str(bodypart_id), path = _get_script_path(bodypart), scene = part_scene})
	return result
